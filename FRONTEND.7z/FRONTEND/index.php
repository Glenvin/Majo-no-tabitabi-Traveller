<!doctype html>
<?php
  include "includes/config.php";
  $query = mysqli_query($connection, "SELECT * FROM area");

  $destinasi = mysqli_query($connection, "SELECT * 
    FROM kategori, destinasi, fotodestinasi
    WHERE kategori.kategoriID = destinasi.kategoriID
    AND destinasi.destinasiID = fotodestinasi.destinasiID");

  $sql = mysqli_query($connection, "SELECT * FROM destinasi");
  $jumlah = mysqli_num_rows($sql);

  $foto = mysqli_query($connection, "SELECT * FROM fotodestinasi");

  $kategori = mysqli_query($connection, "SELECT * FROM kategori");

  $provinsi = mysqli_query($connection, "SELECT * FROM provinsi");

  $hotel = mysqli_query($connection, "SELECT * FROM hotel");

  $restarea = mysqli_query($connection, "SELECT * FROM restarea");

  $restoran = mysqli_query($connection, "SELECT * FROM restoran");
?>



<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="./index.css" rel="stylesheet" type="text/css">
    <title>TRAVELLER</title>
  </head>
  <body>


<!-- MEMBUAT MENU -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="" pe="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Area
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">

        <?php if(mysqli_num_rows($query) > 0){
          while ($row = mysqli_fetch_array($query))
            { ?>
          <a class="dropdown-item" href="#"><?php echo $row["areanama"]?></a>
        <?php } } ?>
        </div>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Destination
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">

        <?php if(mysqli_num_rows($sql) > 0){
          while ($row = mysqli_fetch_array($sql))
            { ?>
          <a class="dropdown-item" href="#"><?php echo $row["destinasinama"]?></a>
        <?php } } ?>
        </div>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Province
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">

        <?php if(mysqli_num_rows($provinsi) > 0){
          while ($row = mysqli_fetch_array($provinsi))
            { ?>
          <a class="dropdown-item" href="#"><?php echo $row["provinsinama"]?></a>
        <?php } } ?>
        </div>

        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Category
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">

        <?php if(mysqli_num_rows($kategori) > 0){
          while ($row = mysqli_fetch_array($kategori))
            { ?>
          <a class="dropdown-item" href="#"><?php echo $row["kategorinama"]?></a>
        <?php } } ?>
        </div>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Hotel
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">

        <?php if(mysqli_num_rows($hotel) > 0){
          while ($row = mysqli_fetch_array($hotel))
            { ?>
          <a class="dropdown-item" href="#"><?php echo $row["hotelnama"]?></a>
        <?php } } ?>
        </div>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Rest Area
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">

        <?php if(mysqli_num_rows($restarea) > 0){
          while ($row = mysqli_fetch_array($restarea))
            { ?>
          <a class="dropdown-item" href="#"><?php echo $row["restareanama"]?></a>
        <?php } } ?>
        </div>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Restoran
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">

        <?php if(mysqli_num_rows($restoran) > 0){
          while ($row = mysqli_fetch_array($restoran))
            { ?>
          <a class="dropdown-item" href="#"><?php echo $row["restorannama"]?></a>
        <?php } } ?>
        </div>

    </ul>
</nav>

<!-- AKHIR MEMBUAT MENU -->

<!-- SLIDER -->
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="./images/img3.jpg" alt="First slide">
      <div class="carousel-caption d-none d-md-block">
         <h1>Lake</h1>
         <p>A lake is an area filled with water, localized in a basin, surrounded by land, apart from any river or other outlet that serves to feed or drain the lake.[1] Lakes lie on land and are not part of the ocean, although like the much larger oceans, they form part of earth's water cycle. Lakes are distinct from lagoons which are generally coastal parts of the ocean. They are generally larger and deeper than ponds, which also lie on land, though there are no official or scientific definitions.[2] Lakes can be contrasted with rivers or streams, which are usually flowing in a channel on land. Most lakes are fed and drained by rivers and streams.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="./images/img1.png" alt="Second slide">
      <div class="carousel-caption d-none d-md-block">
         <h1>Grass</h1>
         <p>Poaceae (/poʊˈeɪsiaɪ/) or Gramineae is a large and nearly ubiquitous family of monocotyledonous flowering plants known as grasses. It includes the cereal grasses, bamboos and the grasses of natural grassland and species cultivated in lawns and pasture. The latter are commonly referred to collectively as grass.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="./images/img2.jpg" alt="Third slide">
      <div class="carousel-caption d-none d-md-block">
         <h1>castle</h1>
         <p>A castle is a type of fortified structure built during the Middle Ages predominantly by the nobility or royalty and by military orders. Scholars debate the scope of the word castle, but usually consider it to be the private fortified residence of a lord or noble. This is distinct from a palace, which is not fortified; from a fortress, which was not always a residence for royalty or nobility; and from a fortified settlement, which was a public defence – though there are many similarities among these types of construction. Usage of the term has varied over time and has been applied to structures as diverse as hill forts and country houses. Over the approximately 900 years that castles were built, they took on a great many forms with many different features, although some, such as curtain walls, arrowslits, and portcullises, were commonplace.</p>
      </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<!-- AKHIR SLIDER -->

<div class="Perkenalan" >
<h1 style="font-size: 50px; text-align: center; padding-bottom: 30px; padding-top: 15px; color:white ;">Majo no tabitabi</h1>
<p style="color: white; padding: 50px; font-size: 18px">Inspired by her favorite book, Elaina ventures out to see the world she's read so much about. Like a leaf on the wind, she travels from one country to another, looking to sate her inquisitiveness and searching for new experiences. She's confronted by humanity in all its forms, whether strange, bizarre, or emotional. Exploration and curiosity drive her journey. Where to next, Elaina?</p>
</div>


<br><br>
<h1 style="font-size: 50px; text-align: center; padding-bottom: 30px; color:purple;">DESTINATION</h1>
<br><br>


<!-- MEMBUAT TAMPILAN OBYEK -->
  <div class="container">
    <div class="row">
      <div class="col-sm-8" style="color:purple;">

<?php if(mysqli_num_rows($destinasi) > 0){
  while ($row2 = mysqli_fetch_array($destinasi)) 
  { ?>
<div class="media">
  <div class="media-body">
    <h4 class="mt-0 mb-1"><?php echo $row2["destinasinama"]?></h4>
    <h5><?php echo $row2["destinasialamat"]?></h5>
    <p style="color:black;"><?php echo $row2["kategoriketerangan"]?></p>
  </div>
  <img class="ml-3" style="width:200px; height: 100px;" src="images/<?php echo $row2["fotofile"]?>" alt="IMAGE NOT FOUND">
</div>
<?php } } ?>


      </div>
      <div class="col-sm-4">
        
<ul class="list-group">
  <li class="list-group-item d-flex justify-content-between align-items-center">
    Destination
    <span class="badge badge-primary badge-pill"><?php echo $jumlah?></span>
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center">
    Dapibus ac facilisis in
    <span class="badge badge-primary badge-pill">2</span>
  </li>
  <li class="list-group-item d-flex justify-content-between align-items-center">
    Morbi leo risus
    <span class="badge badge-primary badge-pill">1</span>
  </li>
</ul>
<br>
<iframe width="350" height="250" src="https://www.youtube.com/embed/OkrbVBUa4S0" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br>
<br>
<br>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2979.357244236094!2d44.80895431481651!3d41.691223035068205!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40440cfa03d5e58d%3A0x89587c400b10c32b!2sEurope%20Square%2C%20T&#39;bilisi%2C%20Georgia!5e0!3m2!1sen!2sid!4v1608488241970!5m2!1sen!2sid" width="350" height="250" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
      </div>
    </div>
  </div>


<!-- END OBYEK -->

<br><br>
<span style="border-bottom-style: solid; border-bottom-width: 5px; margin-bottom: 50px;
border-bottom-color: purple; width: auto; display: block; margin-top: 30px; text-align: center;"></span>

<h1 style="font-size: 50px; text-align: center; padding-bottom: 30px; color:purple;">PICTURE</h1>

<!-- GALERI -->

<div class="container">
<div class="row">

<?php while ($row3 = mysqli_fetch_array($foto))
{?>
<div class="col-sm-4">
<figure class="figure">
  <img src="images/<?php echo $row3["fotofile"]?>" class="figure-img img-fluid rounded" alt="NO IMAGES">
  <figcaption class="figure-caption text-right"></figcaption>
</figure>
</div>
<?php } ?>
</div>
</div>

<!-- END GALERI -->




    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>