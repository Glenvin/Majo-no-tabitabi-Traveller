<?php
	include "includes/config.php";
	if(isset($_GET["hapus"]))
	{
		$kodedestinasi = $_GET["hapus"];
		mysqli_query($connection, "DELETE FROM restoran WHERE restoranID = '$kodedestinasi' ");
		echo "<script>alert('DATA BERHASIL DIHAPUS');
			document.location='restoran.php'</script>";
	}
?>