<?php
	include "includes/config.php";
	if(isset($_GET["hapus"]))
	{
		$kodedestinasi = $_GET["hapus"];
		mysqli_query($connection, "DELETE FROM restarea WHERE restareaID = '$kodedestinasi' ");
		echo "<script>alert('DATA BERHASIL DIHAPUS');
			document.location='restarea.php'</script>";
	}
?>