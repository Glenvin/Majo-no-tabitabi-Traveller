<?php
	include "includes/config.php";
	if(isset($_GET["hapus"]))
	{
		$kodedestinasi = $_GET["hapus"];
		mysqli_query($connection, "DELETE FROM kategori WHERE kategoriID = '$kodedestinasi' ");
		echo "<script>alert('DATA BERHASIL DIHAPUS');
			document.location='kategori.php'</script>";
	}
?>