<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Daftar Admin</title>
</head>

<?php
ob_start();
session_start();
if(!isset($_SESSION["emailuser"]))
	header("location:login.php");
?>

<?php include "header.php";?>

<div class="container-fluid">
<div class="card shadow mb-4">

<?php
	include "includes/config.php";

	if(isset($_POST["Simpan"]))
	{
		if(isset($_REQUEST["inputkode"]))
		{
			$destinasikode = $_REQUEST["inputkode"];
		}

		if(!empty($destinasikode))
		{
			$destinasikode = $_REQUEST["inputkode"];
		}
		else{
			die("Anda harus memasukkan kodenya");
		}

		$destinasinama = $_POST["inputnama"];
		$alamat = $_POST["alamat"];
		$kategori = $_POST["kategori"];

		mysqli_query($connection, "insert into admin values ('$destinasikode', '$destinasinama', '$alamat', '$kategori')");
		header("location:admin.php");
	}

?>

<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Halaman Pendaftaran Admin</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>


<div class="row">
<div class="col-sm-1">
</div>

<div class="col-sm-10">

		<div class="jumbotron jumbotron-fluid">
			<div class="container">
				<h1 class="display-4">Halaman Pendaftaran Admin</h1>
			</div>
		</div> <!-- penutup jumbotron -->

		<form method="POST">
  			<div class="form-group row">
    			<label for="kodedestinasi" class="col-sm-2 col-form-label">Kode Admin</label>
    		<div class="col-sm-10">
      			<input type="text" class="form-control" id="kodedestinasi" name="inputkode" placeholder="Masukkan kode admin" maxlength="4">
    		</div>
  			</div>

  			<div class="form-group row">
    			<label for="namadestinasi" class="col-sm-2 col-form-label">Nama Admin</label>
    		<div class="col-sm-10">
      			<input type="text" class="form-control" id="namadestinasi" name="inputnama" placeholder="Masukkan nama admin">
    		</div>
  			</div>

  			<div class="form-group row">
    			<label for="alamat" class="col-sm-2 col-form-label">Email</label>
    		<div class="col-sm-10">
      			<input type="text" class="form-control" id="alamat" name="alamat" placeholder="Masukkan email">
    		</div>
  			</div>

  			<div class="form-group row">
    			<label for="kategori" class="col-sm-2 col-form-label">Password</label>
    		<div class="col-sm-10">
      			<input type="text" class="form-control" id="kategori" name="kategori" placeholder="Masukkan password">
    		</div>
  			</div>



  			<div class="form-group row">
    			<div class="col-sm-2">
    			</div>
    		<div class="col-sm-10">
      			<input type="submit" class="btn btn-primary" value="Simpan" name="Simpan">
				<input type="reset" class="btn btn-secondary" value="Batal" name="Batal">
    		</div>
  			</div>
		</form>
</div>
<div class="col-sm-1">
</div> 
</div> <!-- penutup class row-->

	</div>
	<div class="col-sm-1"></div>


</div>

<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>



</div>
</div> <!-- penutup container fluid -->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<?php include "footer.php";?>
<?php 
mysqli_close($connection);
ob_end_flush();
?>
</html>