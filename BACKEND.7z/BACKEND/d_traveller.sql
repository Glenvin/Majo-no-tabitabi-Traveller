-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 21, 2020 at 03:40 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `d_traveller`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminID` char(4) NOT NULL,
  `adminNAMA` varchar(30) NOT NULL,
  `adminEMAIL` varchar(60) NOT NULL,
  `adminPASSWORD` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminID`, `adminNAMA`, `adminEMAIL`, `adminPASSWORD`) VALUES
('0001', 'Glenvin', 'UAS@yahoo.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `area`
--

CREATE TABLE `area` (
  `areaID` char(4) NOT NULL,
  `areanama` char(35) NOT NULL,
  `areawilayah` char(35) NOT NULL,
  `areaketerangan` varchar(255) NOT NULL,
  `povinsiID` char(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `area`
--

INSERT INTO `area` (`areaID`, `areanama`, `areawilayah`, `areaketerangan`, `povinsiID`) VALUES
('AR01', 'Wine treadler', 'Utara', '12', 'WK'),
('AR02', 'Monument of Clock Tower', 'Clock tower', '13', 'WK'),
('AR03', 'Majo no Highschool', 'Timur', '14', 'WK'),
('AR04', 'Wish fulfilling island', 'Selatan', '15', 'AS'),
('AR05', 'Flower of the death', 'Gunung arah selatan', '16', 'AS');

-- --------------------------------------------------------

--
-- Table structure for table `destinasi`
--

CREATE TABLE `destinasi` (
  `destinasiID` char(5) NOT NULL,
  `destinasinama` varchar(35) NOT NULL,
  `destinasialamat` varchar(255) NOT NULL,
  `kategoriID` char(4) NOT NULL,
  `areaID` char(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `destinasi`
--

INSERT INTO `destinasi` (`destinasiID`, `destinasinama`, `destinasialamat`, `kategoriID`, `areaID`) VALUES
('WS01', 'Riviere', 'The prayer land of prayer', 'KW01', 'AR03'),
('WS02', 'Clock tower', 'plaza street 72z0', 'KW02', 'AR02'),
('WS04', 'Witch School', 'Witch street A2B1', 'KW03', 'AR04');

-- --------------------------------------------------------

--
-- Table structure for table `fotodestinasi`
--

CREATE TABLE `fotodestinasi` (
  `fotoID` char(5) NOT NULL,
  `fotonama` char(60) NOT NULL,
  `destinasiID` char(4) NOT NULL,
  `fotofile` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fotodestinasi`
--

INSERT INTO `fotodestinasi` (`fotoID`, `fotonama`, `destinasiID`, `fotofile`) VALUES
('F001', 'Foto Wisata 11', 'WS01', 'Duduk.jpg'),
('F002', 'Foto Wisata 22', 'WS02', 'hai.jpg'),
('F003', 'Foto Wisata 3', 'WS04', 'Salju.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `hotel`
--

CREATE TABLE `hotel` (
  `hotelID` char(4) NOT NULL,
  `hotelnama` char(35) NOT NULL,
  `alamathotel` varchar(255) NOT NULL,
  `kategorihotel` char(35) NOT NULL,
  `areaID` char(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hotel`
--

INSERT INTO `hotel` (`hotelID`, `hotelnama`, `alamathotel`, `kategorihotel`, `areaID`) VALUES
('0002', 'Hotel tasmania', 'Snow field street 272', 'atas', 'AR01'),
('HT01', 'Castlemania Hotel', 'Street 21clock tower', 'Menengah Keatas', 'AR01');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `kategoriID` char(4) NOT NULL,
  `kategorinama` char(30) NOT NULL,
  `kategoriketerangan` varchar(255) NOT NULL,
  `kategorireferensi` char(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`kategoriID`, `kategorinama`, `kategoriketerangan`, `kategorireferensi`) VALUES
('KW01', 'Sekolah', 'Disini adalah tempat tinggal dimana para pengguna sihir diizinkan masuk kedalam kota tersebut (biasanya bukan penyihir diusir)', 'Novel Majo no tabitabi'),
('KW02', 'Menara jam', 'Disini adalah tempat kejadian pembunuhan dimana dijaman dahulu terdapat pembunuhan yg tidak dikenal dan pembunuh tersebut dibunuh oleh temennya sendiri dengan cara dipenggal kepalanya', 'Novel Majo no tabitabi'),
('KW03', 'Kota', 'Disini adalah tempat dimana manusia yang ingin berlatih sihir dan ada tahap tahapannya disekolah tersebut', 'Novel Majo no tabitabi'),
('KW04', 'Ladang', 'Ladang dimana dipenuhi oleh bunga-bunga beracun', 'Novel Majo no tabitabi');

-- --------------------------------------------------------

--
-- Table structure for table `provinsi`
--

CREATE TABLE `provinsi` (
  `provinsiID` char(2) NOT NULL,
  `provinsinama` char(25) NOT NULL,
  `provinsitglberdiri` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `provinsi`
--

INSERT INTO `provinsi` (`provinsiID`, `provinsinama`, `provinsitglberdiri`) VALUES
('JK', 'Wind wheel chief', '2021-04-20'),
('WK', 'High school principle', '3010-01-20');

-- --------------------------------------------------------

--
-- Table structure for table `restarea`
--

CREATE TABLE `restarea` (
  `restareaID` char(4) NOT NULL,
  `restareanama` char(35) NOT NULL,
  `alamatrestarea` varchar(255) NOT NULL,
  `kategorirestarea` char(35) NOT NULL,
  `areaID` char(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `restarea`
--

INSERT INTO `restarea` (`restareaID`, `restareanama`, `alamatrestarea`, `kategorirestarea`, `areaID`) VALUES
('RA01', 'Motel of witch', 'Witch street', 'Besar', 'AR01');

-- --------------------------------------------------------

--
-- Table structure for table `restoran`
--

CREATE TABLE `restoran` (
  `restoranID` char(4) NOT NULL,
  `restorannama` char(35) NOT NULL,
  `alamatrestoran` varchar(255) NOT NULL,
  `kategorirestoran` char(35) NOT NULL,
  `areaID` char(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `restoran`
--

INSERT INTO `restoran` (`restoranID`, `restorannama`, `alamatrestoran`, `kategorirestoran`, `areaID`) VALUES
('RT01', 'Breadtalk', 'Clocktower street', 'Sedang', 'AR01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminID`);

--
-- Indexes for table `area`
--
ALTER TABLE `area`
  ADD PRIMARY KEY (`areaID`);

--
-- Indexes for table `destinasi`
--
ALTER TABLE `destinasi`
  ADD PRIMARY KEY (`destinasiID`);

--
-- Indexes for table `fotodestinasi`
--
ALTER TABLE `fotodestinasi`
  ADD PRIMARY KEY (`fotoID`);

--
-- Indexes for table `hotel`
--
ALTER TABLE `hotel`
  ADD PRIMARY KEY (`hotelID`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`kategoriID`);

--
-- Indexes for table `provinsi`
--
ALTER TABLE `provinsi`
  ADD PRIMARY KEY (`provinsiID`);

--
-- Indexes for table `restarea`
--
ALTER TABLE `restarea`
  ADD PRIMARY KEY (`restareaID`);

--
-- Indexes for table `restoran`
--
ALTER TABLE `restoran`
  ADD PRIMARY KEY (`restoranID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
